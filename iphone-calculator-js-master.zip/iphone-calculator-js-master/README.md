# The iPHONE Calculator 📱 1️⃣2️⃣3️⃣

The repo for the iPhone calculator code-along using HTML, CSS, and Vanilla JavaScript!

Symbols used in this app: `± % ÷ × − + =`

Feel free to use this code for your personal projects!

<img src="iphone.png" alt="iphone calculator" style="margin-left: 15px;" />

## Extra Challenges

- Make keyboard inputs work with the calculator
- Limit the visible display number to 9 digits
- Make display font size dynamically change for when you have 6, 7, 8, 9 digits
